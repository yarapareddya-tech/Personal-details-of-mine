// resume_shortlister — minimal client-side interactivity
// Handles drag/drop + filename preview on the resume upload dropzone.

document.addEventListener("DOMContentLoaded", function () {
  const dropzone = document.getElementById("resume-dropzone");
  const fileInput = document.getElementById("resume-input");
  const filenameDisplay = document.getElementById("resume-filename");
  const submitBtn = document.getElementById("upload-submit-btn");

  if (!dropzone || !fileInput) return;

  function showFilename(file) {
    if (!file) return;
    if (filenameDisplay) {
      filenameDisplay.textContent = "Selected: " + file.name;
    }
    if (submitBtn) {
      submitBtn.disabled = false;
    }
  }

  dropzone.addEventListener("click", function () {
    fileInput.click();
  });

  fileInput.addEventListener("change", function () {
    if (fileInput.files && fileInput.files[0]) {
      showFilename(fileInput.files[0]);
    }
  });

  ["dragenter", "dragover"].forEach(function (evt) {
    dropzone.addEventListener(evt, function (e) {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.add("drag-over");
    });
  });

  ["dragleave", "drop"].forEach(function (evt) {
    dropzone.addEventListener(evt, function (e) {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove("drag-over");
    });
  });

  dropzone.addEventListener("drop", function (e) {
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      fileInput.files = files;
      showFilename(files[0]);
    }
  });

  // Auto-dismiss flash messages after a few seconds
  document.querySelectorAll(".flash").forEach(function (el, i) {
    setTimeout(function () {
      el.style.transition = "opacity .4s, transform .4s";
      el.style.opacity = "0";
      el.style.transform = "translateX(12px)";
      setTimeout(function () { el.remove(); }, 400);
    }, 4500 + i * 200);
  });
});
