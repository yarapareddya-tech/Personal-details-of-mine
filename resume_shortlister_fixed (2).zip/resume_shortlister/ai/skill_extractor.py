"""
Extracts known technical/professional skills from raw resume or job-description text.

Approach: maintain a curated skill vocabulary (with common aliases/synonyms),
then do phrase-level matching against the cleaned text. This is far more
reliable for short keyword-style skills ("c++", "power bi", "node.js") than
plain tokenization, since many skills are multi-word or contain symbols.
"""
import re
from ai.preprocessing import clean_text

# Canonical skill -> list of aliases/synonyms that should map to it.
# Extend this freely as you cover more roles (this list focuses on
# software/dev/data roles relevant to fresher tech hiring in India).
SKILL_ALIASES = {
    "python": ["python", "python3", "py"],
    "java": ["java"],
    "c++": ["c++", "cpp"],
    "c": [" c ", "c programming"],
    "c#": ["c#", "c sharp"],
    "javascript": ["javascript", "js", "es6", "ecmascript"],
    "typescript": ["typescript", "ts"],
    "sql": ["sql", "mysql", "postgresql", "postgres", "sqlite", "t-sql", "pl/sql"],
    "nosql": ["nosql", "mongodb", "mongo", "cassandra", "dynamodb"],
    "html": ["html", "html5"],
    "css": ["css", "css3"],
    "react": ["react", "reactjs", "react.js"],
    "angular": ["angular", "angularjs"],
    "vue": ["vue", "vuejs", "vue.js"],
    "node.js": ["node.js", "nodejs", "node"],
    "flask": ["flask"],
    "django": ["django"],
    "fastapi": ["fastapi"],
    "spring boot": ["spring boot", "spring"],
    "rest api": ["rest api", "restful", "rest apis", "api development"],
    "git": ["git", "github", "gitlab", "version control"],
    "docker": ["docker", "containerization"],
    "kubernetes": ["kubernetes", "k8s"],
    "aws": ["aws", "amazon web services", "ec2", "s3 bucket", "lambda"],
    "azure": ["azure", "microsoft azure"],
    "gcp": ["gcp", "google cloud", "google cloud platform"],
    "linux": ["linux", "unix", "bash", "shell scripting"],
    "data structures": ["data structures", "dsa"],
    "algorithms": ["algorithms", "algorithm design"],
    "machine learning": ["machine learning", "ml"],
    "deep learning": ["deep learning", "dl", "neural networks"],
    "nlp": ["nlp", "natural language processing"],
    "computer vision": ["computer vision", "cv", "opencv"],
    "tensorflow": ["tensorflow", "tf"],
    "pytorch": ["pytorch", "torch"],
    "scikit-learn": ["scikit-learn", "sklearn", "scikit learn"],
    "pandas": ["pandas"],
    "numpy": ["numpy"],
    "data analysis": ["data analysis", "data analytics", "analytics"],
    "power bi": ["power bi", "powerbi"],
    "tableau": ["tableau"],
    "excel": ["excel", "ms excel", "spreadsheets"],
    "statistics": ["statistics", "statistical analysis"],
    "data visualization": ["data visualization", "data viz"],
    "agile": ["agile", "scrum", "kanban"],
    "ci/cd": ["ci/cd", "continuous integration", "continuous deployment", "jenkins"],
    "testing": ["unit testing", "test automation", "selenium", "pytest", "junit"],
    "android": ["android", "android development", "kotlin"],
    "ios": ["ios", "swift", "objective-c"],
    "flutter": ["flutter", "dart"],
    "communication": ["communication skills", "verbal communication"],
    "leadership": ["leadership", "team lead", "people management"],
    "problem solving": ["problem solving", "analytical skills", "critical thinking"],
    "project management": ["project management", "jira", "pmp"],
    "graphql": ["graphql"],
    "microservices": ["microservices", "microservice architecture"],
    "blockchain": ["blockchain", "smart contracts", "solidity", "web3"],
    "data engineering": ["data engineering", "etl", "data pipeline", "apache spark", "spark", "hadoop"],
}

# Build a flat alias -> canonical lookup once at import time.
_ALIAS_TO_CANONICAL = {}
for canonical, aliases in SKILL_ALIASES.items():
    for alias in aliases:
        _ALIAS_TO_CANONICAL[alias.strip().lower()] = canonical


def _phrase_in_text(phrase, padded_text):
    """Whole-word/phrase match using word boundaries where safe to do so."""
    phrase = phrase.strip().lower()
    if not phrase:
        return False
    # Symbols like c++, c#, node.js need a looser boundary check.
    if re.search(r"[^a-z0-9\s]", phrase):
        return phrase in padded_text
    pattern = r"(?<![a-z0-9])" + re.escape(phrase) + r"(?![a-z0-9])"
    return re.search(pattern, padded_text) is not None


def extract_skills(text):
    """
    Scan input text for any known skill (by canonical name or alias).
    Returns a sorted list of canonical skill names found.
    """
    padded_text = " " + clean_text(text) + " "
    found = set()
    for alias, canonical in _ALIAS_TO_CANONICAL.items():
        if _phrase_in_text(alias, padded_text):
            found.add(canonical)
    return sorted(found)


def extract_skills_from_list(skill_csv_string):
    """
    For job postings where the admin types a comma-separated required-skills
    string directly (e.g. "Python, SQL, Power BI"). Normalizes each entry to
    its canonical form when recognized, otherwise keeps the raw term.
    """
    raw_skills = [s.strip().lower() for s in skill_csv_string.split(",") if s.strip()]
    normalized = []
    for raw in raw_skills:
        canonical = _ALIAS_TO_CANONICAL.get(raw)
        normalized.append(canonical if canonical else raw)
    # de-duplicate, preserve order
    seen = set()
    result = []
    for s in normalized:
        if s not in seen:
            seen.add(s)
            result.append(s)
    return result
