"""
Text cleaning utilities shared by skill_extractor and matcher.
Kept dependency-light (no spaCy/NLTK download requirement) so the app
runs out-of-the-box. Uses simple regex-based tokenization + a small
built-in stopword list.
"""
import re

STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
    "any", "are", "as", "at", "be", "because", "been", "before", "being", "below",
    "between", "both", "but", "by", "could", "did", "do", "does", "doing", "down",
    "during", "each", "few", "for", "from", "further", "had", "has", "have",
    "having", "he", "her", "here", "hers", "herself", "him", "himself", "his",
    "how", "i", "if", "in", "into", "is", "it", "its", "itself", "me", "more",
    "most", "my", "myself", "no", "nor", "not", "of", "off", "on", "once",
    "only", "or", "other", "our", "ours", "ourselves", "out", "over", "own",
    "same", "she", "should", "so", "some", "such", "than", "that", "the",
    "their", "theirs", "them", "themselves", "then", "there", "these", "they",
    "this", "those", "through", "to", "too", "under", "until", "up", "very",
    "was", "we", "were", "what", "when", "where", "which", "while", "who",
    "whom", "why", "will", "with", "you", "your", "yours", "yourself",
    "yourselves", "etc", "e.g", "i.e",
}


def clean_text(text):
    """Lowercase, strip emails/phone numbers/urls/special chars, collapse whitespace."""
    text = text.lower()
    text = re.sub(r"\S+@\S+\.\S+", " ", text)          # emails
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)  # urls
    text = re.sub(r"\+?\d[\d\-\s()]{7,}\d", " ", text)   # phone numbers
    text = re.sub(r"[^a-z0-9+#\.\s]", " ", text)         # keep alnum + (c++, c#, node.js)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def tokenize(text):
    cleaned = clean_text(text)
    tokens = cleaned.split(" ")
    tokens = [t for t in tokens if t and t not in STOPWORDS and len(t) > 1]
    return tokens


def remove_stopwords_text(text):
    """Returns cleaned text with stopwords removed, joined back as a string
    (useful for feeding into TF-IDF, which does its own tokenizing)."""
    return " ".join(tokenize(text))
