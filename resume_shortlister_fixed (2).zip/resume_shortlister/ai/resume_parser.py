"""
Extracts raw text from uploaded resume PDFs.
Uses pdfplumber (handles most text-based PDFs well, including simple tables).

IMPORTANT: many real-world resume PDFs (Canva exports, certain Word/Docs ->
PDF pipelines, some resume-builder sites) embed fonts with unusual
character/word spacing metadata. pdfplumber's default word-tolerance
settings then produce one of two broken outputs even though the PDF is
perfectly text-based:

  1. "Squished" text - words run together with no spaces at all, e.g.
     "SkilledinPythonSQLandFlask"
  2. "Letter-spaced" text - every character comes out separated, e.g.
     "P y t h o n S Q L"

Both are silent failures: extraction "succeeds" (so we never hit the
scanned-PDF error path) but the resulting text is useless for skill/
keyword matching, which is why scores can come out as 0/100 even when
the resume clearly lists the required skills.

To guard against this we extract with a few different word-tolerance
settings and pick whichever result looks the most like normal English
text (based on average token length), instead of trusting the default
blindly.
"""
import re
import pdfplumber


class ResumeParseError(Exception):
    pass


# (x_tolerance, y_tolerance) candidates to try, tuned to catch both the
# "words squished together" and "letters spaced apart" failure modes.
_TOLERANCE_CANDIDATES = [
    (3, 3),   # pdfplumber default
    (1, 3),   # more sensitive to small gaps -> un-squishes joined words
    (6, 3),   # more tolerant of gaps -> merges over-spaced letters
    (10, 3),  # aggressive merge, for badly letter-spaced fonts
]


def _avg_token_length(text):
    tokens = re.findall(r"[a-zA-Z0-9]+", text)
    if not tokens:
        return 0
    return sum(len(t) for t in tokens) / len(tokens)


def _looks_healthy(text):
    """
    Normal English resume text has an average alnum-token length in
    roughly the 3-9 range. Much lower usually means letters got split
    apart; much higher usually means words got squished together.
    """
    avg_len = _avg_token_length(text)
    return 3 <= avg_len <= 9, avg_len


def _fix_letter_spacing(text):
    """
    Safety net for text that still comes out letter-spaced after
    extraction (e.g. 'P y t h o n'). Collapses runs of 3+ single
    characters separated by single spaces into one word, without
    touching normal multi-letter words or genuine single-letter words
    (like the article 'a' or initials followed by a period).
    """
    def collapse(match):
        return match.group(0).replace(" ", "")

    # Matches sequences like "a b c d" (3+ single alnum chars, space-joined)
    pattern = r"\b(?:[a-zA-Z0-9] ){2,}[a-zA-Z0-9]\b"
    return re.sub(pattern, collapse, text)


def _extract_with_tolerance(pdf, x_tol, y_tol):
    chunks = []
    for page in pdf.pages:
        page_text = page.extract_text(x_tolerance=x_tol, y_tolerance=y_tol) or ""
        chunks.append(page_text)
    return "\n".join(chunks).strip()


def extract_text_from_pdf(filepath):
    """
    Extract all text from a PDF file, self-correcting for the common
    "squished together" / "letter spaced apart" extraction failures.
    Returns a single string with page texts joined by newlines.
    Raises ResumeParseError if no extractable text is found at all
    (e.g. the PDF is a scanned image with no OCR layer).
    """
    candidates = []
    try:
        with pdfplumber.open(filepath) as pdf:
            for x_tol, y_tol in _TOLERANCE_CANDIDATES:
                text = _extract_with_tolerance(pdf, x_tol, y_tol)
                if text:
                    candidates.append(text)
    except Exception as e:
        raise ResumeParseError(f"Could not read PDF: {e}")

    if not candidates:
        raise ResumeParseError(
            "No extractable text found in this PDF. "
            "It may be a scanned/image-only resume — please upload a text-based PDF."
        )

    # Pick the candidate whose average token length looks most like
    # normal English (closest to the healthy 3-9 range), rather than
    # just trusting the first/default extraction.
    best_text = None
    best_distance = None
    for text in candidates:
        healthy, avg_len = _looks_healthy(text)
        target = min(max(avg_len, 3), 9)  # clamp target into healthy range
        distance = abs(avg_len - target) if not healthy else 0
        if best_distance is None or distance < best_distance:
            best_distance = distance
            best_text = text
        if healthy:
            break  # good enough, stop trying more tolerances

    full_text = _fix_letter_spacing(best_text).strip()

    if not full_text:
        raise ResumeParseError(
            "No extractable text found in this PDF. "
            "It may be a scanned/image-only resume — please upload a text-based PDF."
        )

    return full_text
