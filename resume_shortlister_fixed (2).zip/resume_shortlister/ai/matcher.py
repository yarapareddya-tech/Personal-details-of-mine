"""
Core matching engine: scores a candidate's resume against a job description using:

1. Skill-overlap score   -> % of the job's required skills found in the resume
2. TF-IDF cosine similarity -> overall textual/contextual similarity between
   resume and job description (catches relevant experience phrased differently
   than the exact skill keywords)

Final score = weighted blend of the two (weights configurable in config.py).
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from ai.preprocessing import remove_stopwords_text
from ai.skill_extractor import extract_skills, extract_skills_from_list


def compute_skill_match(resume_text, required_skills_csv):
    """
    Returns (score_percent, matched_skills, missing_skills).
    score_percent is 0-100: percentage of required skills found in the resume.
    """
    required_skills = extract_skills_from_list(required_skills_csv)
    if not required_skills:
        return 0.0, [], []

    resume_skills = set(extract_skills(resume_text))

    matched = [s for s in required_skills if s in resume_skills]
    missing = [s for s in required_skills if s not in resume_skills]

    score_percent = (len(matched) / len(required_skills)) * 100
    return round(score_percent, 2), matched, missing


def compute_similarity_score(resume_text, job_description_text):
    """
    Returns a 0-100 cosine-similarity score between resume and job description,
    using TF-IDF vectorization over both documents.
    """
    doc_resume = remove_stopwords_text(resume_text)
    doc_job = remove_stopwords_text(job_description_text)

    if not doc_resume.strip() or not doc_job.strip():
        return 0.0

    vectorizer = TfidfVectorizer()
    try:
        tfidf_matrix = vectorizer.fit_transform([doc_resume, doc_job])
    except ValueError:
        # Happens if vocabulary ends up empty after cleaning (e.g. very short text)
        return 0.0

    sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
    return round(float(sim) * 100, 2)


def compute_final_score(resume_text, job, skill_weight=0.6, similarity_weight=0.4):
    """
    job: a Job model instance (has .description and .required_skills)

    Returns a dict with all component scores, ready to persist via the
    Score model and display in admin/candidate dashboards.
    """
    skill_score, matched_skills, missing_skills = compute_skill_match(
        resume_text, job.required_skills
    )
    similarity_score = compute_similarity_score(resume_text, job.description)

    final_score = (skill_score * skill_weight) + (similarity_score * similarity_weight)
    final_score = round(final_score, 2)

    return {
        "skill_match_score": skill_score,
        "similarity_score": similarity_score,
        "final_score": final_score,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
    }
