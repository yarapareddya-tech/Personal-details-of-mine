"""
Ranking and shortlist-decision logic, built on top of matcher.py scores.
"""
from ai.matcher import compute_final_score


def score_and_rank_application(resume_text, job):
    """
    Scores a single resume against a job and returns the score breakdown
    plus a boolean for whether it clears the auto-shortlist threshold.
    """
    from flask import current_app

    result = compute_final_score(
        resume_text,
        job,
        skill_weight=current_app.config.get("SKILL_MATCH_WEIGHT", 0.6),
        similarity_weight=current_app.config.get("SIMILARITY_WEIGHT", 0.4),
    )

    threshold = current_app.config.get("SHORTLIST_THRESHOLD", 50.0)
    result["shortlisted"] = result["final_score"] >= threshold
    return result


def find_best_job_for_resume(resume_text, jobs):
    """
    Given a parsed resume and a list of active Job objects, scores the resume
    against every job and returns the ranked list (best match first), each
    entry as a dict: {"job": Job, **score_breakdown}.

    Used for the "just upload your resume, get auto-matched" candidate flow.
    """
    ranked = []
    for job in jobs:
        breakdown = score_and_rank_application(resume_text, job)
        ranked.append({"job": job, **breakdown})

    ranked.sort(key=lambda r: r["final_score"], reverse=True)
    return ranked


def rank_candidates_for_job(applications_with_resume_text, job):
    """
    Given a list of (Application, resume_text) tuples for one job, returns
    them sorted best-to-worst with score breakdowns attached.
    Used for the admin "view applicants for this job" screen if you want to
    (re)compute live rather than reading persisted scores.
    """
    results = []
    for application, resume_text in applications_with_resume_text:
        breakdown = score_and_rank_application(resume_text, job)
        results.append({"application": application, **breakdown})

    results.sort(key=lambda r: r["final_score"], reverse=True)
    return results
