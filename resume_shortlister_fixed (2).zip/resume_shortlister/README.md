# Resume Shortlister

A Flask app with two roles:

- **Admin** — posts jobs (title, description, required skills, min experience), then reviews
  applicants for each job in a ranked ledger, and can manually shortlist/reject.
- **Candidate** — uploads one resume PDF. The app auto-extracts the text, scores it against
  every *active* job, and applies the candidate to the single best-matching job. The result
  page shows the score breakdown plus how the resume would have scored against other open roles.

## How matching works (no external API, fully offline)

For a given resume vs. a job:

1. **Skill overlap score** — `ai/skill_extractor.py` holds a curated skill vocabulary (with
   aliases, e.g. "node.js"/"nodejs"/"node" all map to one canonical skill). It scans both the
   job's `required_skills` field and the resume text for these terms, and the score is
   `(matched skills / required skills) * 100`.
2. **TF-IDF cosine similarity** — `ai/matcher.py` vectorizes the resume text and the full job
   description with scikit-learn's `TfidfVectorizer`, then computes cosine similarity. This
   catches relevant experience phrased differently than the exact skill keywords.
3. **Final score** = `0.6 * skill_score + 0.4 * similarity_score` (weights in `config.py`).
4. If `final_score >= SHORTLIST_THRESHOLD` (default 50), the application is auto-marked
   `shortlisted`; otherwise `pending`. Admins can override either way.

To extend the skill vocabulary, just add entries to `SKILL_ALIASES` in
`ai/skill_extractor.py` — no code changes needed elsewhere.

## Setup

```bash
cd resume_shortlister
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

App runs at `http://localhost:5000`. The SQLite database and its tables are created
automatically on first run (`database/database.db`).

## Trying it out

1. Go to `/register`, create an **Admin** account.
2. Log in, click **+ New Posting**, create a job (e.g. title "Backend Intern", paste a JD,
   list required skills like `Python, Flask, SQL, Git`).
3. Log out, register a **Candidate** account.
4. Log in as the candidate, go to **Upload Resume**, drop a text-based PDF resume.
5. You'll land on the match result page with the score breakdown.
6. Log back in as admin to see the candidate in the job's ranked applicant ledger, and
   shortlist/reject them.

## Notes / things you may want to adjust

- **Scanned/image-only PDFs won't work** — `ai/resume_parser.py` uses `pdfplumber`, which
  extracts text directly from the PDF. If a resume is a scanned image with no text layer,
  the app shows a clear error asking for a text-based PDF. Add OCR (e.g. `pytesseract`) if
  you need to support scanned resumes.
- **One resume = one application.** Right now each candidate is auto-applied to their single
  best-matching active job. If you want candidates to apply to multiple jobs with the same
  resume, that's a small extension to `routes/candidate.py` (loop over `find_best_job_for_resume`
  results instead of taking only `ranked[0]`).
- **"Job portal" integration**: this build treats your own admin-posted jobs as the job
  source — candidates match against jobs created inside this app. Pulling live postings from
  an external portal (LinkedIn, Naukri, Indeed, etc.) needs that portal's official API/partner
  access, which is a separate integration project, not something addable purely in code.
- **Secret key**: `config.py` has a hardcoded dev `SECRET_KEY` — set the `SECRET_KEY`
  environment variable before deploying anywhere real.
