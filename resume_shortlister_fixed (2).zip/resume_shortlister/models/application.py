from database.db import get_db


class Application:
    def __init__(self, row):
        self.id = row["id"]
        self.candidate_id = row["candidate_id"]
        self.job_id = row["job_id"]
        self.resume_filename = row["resume_filename"]
        self.resume_text = row["resume_text"]
        self.status = row["status"]
        self.created_at = row["created_at"]

    @staticmethod
    def create(candidate_id, job_id, resume_filename, resume_text, status="pending"):
        db = get_db()
        cur = db.execute(
            """INSERT INTO applications (candidate_id, job_id, resume_filename, resume_text, status)
               VALUES (?, ?, ?, ?, ?)""",
            (candidate_id, job_id, resume_filename, resume_text, status),
        )
        db.commit()
        return cur.lastrowid

    @staticmethod
    def get_by_id(app_id):
        db = get_db()
        row = db.execute("SELECT * FROM applications WHERE id = ?", (app_id,)).fetchone()
        return Application(row) if row else None

    @staticmethod
    def get_by_candidate(candidate_id):
        db = get_db()
        rows = db.execute(
            "SELECT * FROM applications WHERE candidate_id = ? ORDER BY created_at DESC",
            (candidate_id,),
        ).fetchall()
        return [Application(r) for r in rows]

    @staticmethod
    def get_by_job(job_id):
        db = get_db()
        rows = db.execute(
            "SELECT * FROM applications WHERE job_id = ? ORDER BY created_at DESC", (job_id,)
        ).fetchall()
        return [Application(r) for r in rows]

    @staticmethod
    def update_status(app_id, status):
        db = get_db()
        db.execute("UPDATE applications SET status = ? WHERE id = ?", (status, app_id))
        db.commit()

    @staticmethod
    def get_joined_for_job(job_id):
        """Returns applications joined with candidate info and score, for the admin view."""
        db = get_db()
        rows = db.execute(
            """
            SELECT
                a.id AS application_id,
                a.resume_filename,
                a.status,
                a.created_at,
                u.id AS candidate_id,
                u.name AS candidate_name,
                u.email AS candidate_email,
                s.skill_match_score,
                s.similarity_score,
                s.final_score,
                s.matched_skills,
                s.missing_skills
            FROM applications a
            JOIN users u ON u.id = a.candidate_id
            LEFT JOIN scores s ON s.application_id = a.id
            WHERE a.job_id = ?
            ORDER BY s.final_score DESC
            """,
            (job_id,),
        ).fetchall()
        return rows

    @staticmethod
    def get_joined_for_candidate(candidate_id):
        """Returns applications joined with job info and score, for the candidate dashboard."""
        db = get_db()
        rows = db.execute(
            """
            SELECT
                a.id AS application_id,
                a.resume_filename,
                a.status,
                a.created_at,
                j.id AS job_id,
                j.title AS job_title,
                s.skill_match_score,
                s.similarity_score,
                s.final_score,
                s.matched_skills,
                s.missing_skills
            FROM applications a
            JOIN jobs j ON j.id = a.job_id
            LEFT JOIN scores s ON s.application_id = a.id
            WHERE a.candidate_id = ?
            ORDER BY a.created_at DESC
            """,
            (candidate_id,),
        ).fetchall()
        return rows
