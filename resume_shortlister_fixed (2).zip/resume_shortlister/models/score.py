from database.db import get_db


class Score:
    def __init__(self, row):
        self.id = row["id"]
        self.application_id = row["application_id"]
        self.skill_match_score = row["skill_match_score"]
        self.similarity_score = row["similarity_score"]
        self.final_score = row["final_score"]
        self.matched_skills = row["matched_skills"]
        self.missing_skills = row["missing_skills"]
        self.created_at = row["created_at"]

    @staticmethod
    def create(application_id, skill_match_score, similarity_score, final_score,
               matched_skills, missing_skills):
        db = get_db()
        cur = db.execute(
            """INSERT INTO scores
               (application_id, skill_match_score, similarity_score, final_score,
                matched_skills, missing_skills)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (application_id, skill_match_score, similarity_score, final_score,
             ", ".join(matched_skills), ", ".join(missing_skills)),
        )
        db.commit()
        return cur.lastrowid

    @staticmethod
    def get_by_application(application_id):
        db = get_db()
        row = db.execute(
            "SELECT * FROM scores WHERE application_id = ?", (application_id,)
        ).fetchone()
        return Score(row) if row else None
