from database.db import get_db


class Job:
    def __init__(self, row):
        self.id = row["id"]
        self.title = row["title"]
        self.description = row["description"]
        self.required_skills = row["required_skills"]
        self.min_experience = row["min_experience"]
        self.created_by = row["created_by"]
        self.is_active = row["is_active"]
        self.created_at = row["created_at"]

    @property
    def skill_list(self):
        return [s.strip().lower() for s in self.required_skills.split(",") if s.strip()]

    @staticmethod
    def create(title, description, required_skills, min_experience, created_by):
        db = get_db()
        cur = db.execute(
            """INSERT INTO jobs (title, description, required_skills, min_experience, created_by)
               VALUES (?, ?, ?, ?, ?)""",
            (title, description, required_skills, min_experience, created_by),
        )
        db.commit()
        return cur.lastrowid

    @staticmethod
    def get_by_id(job_id):
        db = get_db()
        row = db.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        return Job(row) if row else None

    @staticmethod
    def get_all_active():
        db = get_db()
        rows = db.execute(
            "SELECT * FROM jobs WHERE is_active = 1 ORDER BY created_at DESC"
        ).fetchall()
        return [Job(r) for r in rows]

    @staticmethod
    def get_all_by_creator(user_id):
        db = get_db()
        rows = db.execute(
            "SELECT * FROM jobs WHERE created_by = ? ORDER BY created_at DESC", (user_id,)
        ).fetchall()
        return [Job(r) for r in rows]

    @staticmethod
    def set_active(job_id, is_active):
        db = get_db()
        db.execute("UPDATE jobs SET is_active = ? WHERE id = ?", (int(is_active), job_id))
        db.commit()
