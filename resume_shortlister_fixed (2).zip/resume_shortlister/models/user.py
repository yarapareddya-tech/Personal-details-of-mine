from werkzeug.security import generate_password_hash, check_password_hash
from database.db import get_db


class User:
    def __init__(self, row):
        self.id = row["id"]
        self.name = row["name"]
        self.email = row["email"]
        self.password_hash = row["password_hash"]
        self.role = row["role"]
        self.created_at = row["created_at"]

    @staticmethod
    def create(name, email, password, role):
        db = get_db()
        password_hash = generate_password_hash(password)
        cur = db.execute(
            "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
            (name, email, password_hash, role),
        )
        db.commit()
        return cur.lastrowid

    @staticmethod
    def get_by_id(user_id):
        db = get_db()
        row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        return User(row) if row else None

    @staticmethod
    def get_by_email(email):
        db = get_db()
        row = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        return User(row) if row else None

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
