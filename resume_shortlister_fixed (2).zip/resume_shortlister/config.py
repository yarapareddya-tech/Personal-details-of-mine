import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-in-production")

    # Database
    DATABASE_PATH = os.path.join(BASE_DIR, "database", "database.db")

    # File uploads
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads", "resumes")
    ALLOWED_EXTENSIONS = {"pdf"}
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024  # 8 MB max per resume

    # Matching engine
    # Score below this threshold = auto-rejected / not shortlisted
    SHORTLIST_THRESHOLD = 50.0  # percentage

    # Weighting between skill-overlap score and TF-IDF cosine-similarity score
    SKILL_MATCH_WEIGHT = 0.6
    SIMILARITY_WEIGHT = 0.4
