from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, session, flash

from models.user import User

bp = Blueprint("auth", __name__)


def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return wrapped


def role_required(role):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in to continue.", "warning")
                return redirect(url_for("auth.login"))
            if session.get("role") != role:
                flash("You don't have access to that page.", "danger")
                return redirect(url_for("auth.dashboard_redirect"))
            return f(*args, **kwargs)
        return wrapped
    return decorator


@bp.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("auth.dashboard_redirect"))
    return redirect(url_for("auth.login"))


@bp.route("/dashboard")
def dashboard_redirect():
    if session.get("role") == "admin":
        return redirect(url_for("admin.dashboard"))
    elif session.get("role") == "candidate":
        return redirect(url_for("candidate.dashboard"))
    return redirect(url_for("auth.login"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        role = request.form.get("role", "candidate")

        if role not in ("admin", "candidate"):
            role = "candidate"

        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("register.html")

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
            return render_template("register.html")

        if User.get_by_email(email):
            flash("An account with that email already exists.", "danger")
            return render_template("register.html")

        User.create(name, email, password, role)
        flash("Account created successfully. Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        user = User.get_by_email(email)
        if user and user.check_password(password):
            session["user_id"] = user.id
            session["name"] = user.name
            session["role"] = user.role
            flash(f"Welcome back, {user.name}!", "success")
            return redirect(url_for("auth.dashboard_redirect"))

        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))
