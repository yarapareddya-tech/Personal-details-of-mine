from flask import Blueprint, render_template, request, redirect, url_for, session, flash

from models.job import Job
from routes.auth import role_required

bp = Blueprint("jobs", __name__)


@bp.route("/admin/jobs/create", methods=["GET", "POST"])
@role_required("admin")
def create_job():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        required_skills = request.form.get("required_skills", "").strip()
        min_experience = request.form.get("min_experience", "0").strip()

        if not title or not description or not required_skills:
            flash("Title, description, and required skills are all required.", "danger")
            return render_template("create_job.html")

        try:
            min_experience = float(min_experience) if min_experience else 0.0
        except ValueError:
            min_experience = 0.0

        Job.create(
            title=title,
            description=description,
            required_skills=required_skills,
            min_experience=min_experience,
            created_by=session["user_id"],
        )
        flash(f'Job "{title}" posted successfully.', "success")
        return redirect(url_for("admin.dashboard"))

    return render_template("create_job.html")


@bp.route("/admin/jobs/<int:job_id>/toggle", methods=["POST"])
@role_required("admin")
def toggle_job(job_id):
    job = Job.get_by_id(job_id)
    if not job or job.created_by != session["user_id"]:
        flash("Job not found.", "danger")
        return redirect(url_for("admin.dashboard"))

    Job.set_active(job_id, not job.is_active)
    flash("Job status updated.", "success")
    return redirect(url_for("admin.dashboard"))
