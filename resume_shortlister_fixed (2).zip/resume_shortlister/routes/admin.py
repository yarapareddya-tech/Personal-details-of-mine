from flask import Blueprint, render_template, redirect, url_for, session, flash

from models.job import Job
from models.application import Application
from routes.auth import role_required

bp = Blueprint("admin", __name__)


@bp.route("/admin/dashboard")
@role_required("admin")
def dashboard():
    jobs = Job.get_all_by_creator(session["user_id"])
    # Attach applicant counts for a quick overview
    job_stats = []
    for job in jobs:
        apps = Application.get_by_job(job.id)
        shortlisted_count = sum(1 for a in apps if a.status == "shortlisted")
        job_stats.append({
            "job": job,
            "total_applicants": len(apps),
            "shortlisted_count": shortlisted_count,
        })
    return render_template("admin_dashboard.html", job_stats=job_stats)


@bp.route("/admin/jobs/<int:job_id>/applicants")
@role_required("admin")
def applicants(job_id):
    job = Job.get_by_id(job_id)
    if not job or job.created_by != session["user_id"]:
        flash("Job not found.", "danger")
        return redirect(url_for("admin.dashboard"))

    rows = Application.get_joined_for_job(job_id)
    return render_template("applicants.html", job=job, rows=rows)


@bp.route("/admin/jobs/<int:job_id>/shortlisted")
@role_required("admin")
def shortlisted(job_id):
    job = Job.get_by_id(job_id)
    if not job or job.created_by != session["user_id"]:
        flash("Job not found.", "danger")
        return redirect(url_for("admin.dashboard"))

    rows = Application.get_joined_for_job(job_id)
    rows = [r for r in rows if r["status"] == "shortlisted"]
    return render_template("shortlisted.html", job=job, rows=rows)


@bp.route("/admin/applications/<int:application_id>/shortlist", methods=["POST"])
@role_required("admin")
def mark_shortlisted(application_id):
    application = Application.get_by_id(application_id)
    if not application:
        flash("Application not found.", "danger")
        return redirect(url_for("admin.dashboard"))

    job = Job.get_by_id(application.job_id)
    if not job or job.created_by != session["user_id"]:
        flash("Not authorized.", "danger")
        return redirect(url_for("admin.dashboard"))

    Application.update_status(application_id, "shortlisted")
    flash("Candidate shortlisted.", "success")
    return redirect(url_for("admin.applicants", job_id=application.job_id))


@bp.route("/admin/applications/<int:application_id>/reject", methods=["POST"])
@role_required("admin")
def mark_rejected(application_id):
    application = Application.get_by_id(application_id)
    if not application:
        flash("Application not found.", "danger")
        return redirect(url_for("admin.dashboard"))

    job = Job.get_by_id(application.job_id)
    if not job or job.created_by != session["user_id"]:
        flash("Not authorized.", "danger")
        return redirect(url_for("admin.dashboard"))

    Application.update_status(application_id, "rejected")
    flash("Candidate rejected.", "info")
    return redirect(url_for("admin.applicants", job_id=application.job_id))
