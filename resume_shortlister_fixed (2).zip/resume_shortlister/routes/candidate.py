import os
import uuid

from flask import (
    Blueprint, render_template, request, redirect, url_for,
    session, flash, current_app, send_from_directory
)
from werkzeug.utils import secure_filename

from models.job import Job
from models.application import Application
from models.score import Score
from routes.auth import role_required
from ai.resume_parser import extract_text_from_pdf, ResumeParseError
from ai.ranking import find_best_job_for_resume, score_and_rank_application

bp = Blueprint("candidate", __name__)


def _allowed_file(filename):
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return ext in current_app.config["ALLOWED_EXTENSIONS"]


@bp.route("/candidate/dashboard")
@role_required("candidate")
def dashboard():
    applications = Application.get_joined_for_candidate(session["user_id"])
    return render_template("candidate_dashboard.html", applications=applications)


@bp.route("/candidate/upload", methods=["GET", "POST"])
@role_required("candidate")
def upload_resume():
    if request.method == "POST":
        if "resume" not in request.files:
            flash("Please select a PDF file to upload.", "danger")
            return redirect(url_for("candidate.upload_resume"))

        file = request.files["resume"]
        if file.filename == "":
            flash("Please select a PDF file to upload.", "danger")
            return redirect(url_for("candidate.upload_resume"))

        if not _allowed_file(file.filename):
            flash("Only PDF files are accepted.", "danger")
            return redirect(url_for("candidate.upload_resume"))

        # Save with a unique name so multiple candidates can't collide
        original_name = secure_filename(file.filename)
        unique_name = f"{uuid.uuid4().hex}_{original_name}"
        save_path = os.path.join(current_app.config["UPLOAD_FOLDER"], unique_name)
        os.makedirs(current_app.config["UPLOAD_FOLDER"], exist_ok=True)
        file.save(save_path)

        # Extract text
        try:
            resume_text = extract_text_from_pdf(save_path)
        except ResumeParseError as e:
            os.remove(save_path)
            flash(str(e), "danger")
            return redirect(url_for("candidate.upload_resume"))

        # Match against every active job
        active_jobs = Job.get_all_active()
        if not active_jobs:
            flash("No active job postings right now. Please check back later.", "warning")
            return redirect(url_for("candidate.dashboard"))

        ranked = find_best_job_for_resume(resume_text, active_jobs)
        best_match = ranked[0]
        best_job = best_match["job"]

        # Create one application against the best-matched job, store the score
        status = "shortlisted" if best_match["shortlisted"] else "pending"
        app_id = Application.create(
            candidate_id=session["user_id"],
            job_id=best_job.id,
            resume_filename=unique_name,
            resume_text=resume_text,
            status=status,
        )
        Score.create(
            application_id=app_id,
            skill_match_score=best_match["skill_match_score"],
            similarity_score=best_match["similarity_score"],
            final_score=best_match["final_score"],
            matched_skills=best_match["matched_skills"],
            missing_skills=best_match["missing_skills"],
        )

        flash(
            f'Resume matched to "{best_job.title}" with a score of '
            f'{best_match["final_score"]}%.',
            "success",
        )
        return redirect(url_for("candidate.match_results", application_id=app_id))

    return render_template("candidate_dashboard.html", upload_mode=True, applications=[])


@bp.route("/candidate/results/<int:application_id>")
@role_required("candidate")
def match_results(application_id):
    application = Application.get_by_id(application_id)
    if not application or application.candidate_id != session["user_id"]:
        flash("Application not found.", "danger")
        return redirect(url_for("candidate.dashboard"))

    job = Job.get_by_id(application.job_id)
    score = Score.get_by_application(application_id)

    # Also show how this resume would have scored against other active jobs,
    # so the candidate can see if a different posting suits them better.
    other_jobs = [j for j in Job.get_all_active() if j.id != job.id]
    alt_matches = []
    if other_jobs:
        ranked = find_best_job_for_resume(application.resume_text, other_jobs)
        alt_matches = ranked[:3]  # top 3 alternates

    return render_template(
        "candidate_dashboard.html",
        result_mode=True,
        application=application,
        job=job,
        score=score,
        alt_matches=alt_matches,
        applications=[],
    )


@bp.route("/uploads/resumes/<path:filename>")
@role_required("admin")
def download_resume(filename):
    """Admin-only download of a candidate's uploaded resume PDF."""
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], filename, as_attachment=False)
