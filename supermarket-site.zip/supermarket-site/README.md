# Mandi Fresh — Supermarket Website

A single, self-contained front-end website for listing supermarket products with
photos, prices, and discounts, plus an interactive shopping experience.

## What's inside
- `index.html` — page structure
- `styles.css` — the "market crate" visual design (chalkboard price tags, rotated sale stamp)
- `script.js` — product data, search, category filters, sorting, and a working cart with basket drawer

## Features
- 26 sample products across 6 categories (Fruits & Vegetables, Dairy & Eggs, Bakery, Beverages, Snacks, Household)
- Product photos, current price, and strikethrough original price + discount badge on sale items
- Live search box
- Category filter pills
- Sort by price or biggest discount
- Add to basket, adjust quantity, remove items
- Slide-out cart drawer showing total and total savings
- Cart persists between visits (saved in the browser)
- Fully responsive, keyboard-accessible

## How to use
1. Unzip the folder.
2. Open `index.html` in any web browser (double-click it, or right-click → Open with).
3. No build step, server, or install needed — it's plain HTML/CSS/JS.

## Customizing
- Edit the `PRODUCTS` array at the top of `script.js` to change items, prices, discounts, images, or categories.
- Product photos are pulled live from a free stock-photo service by keyword — swap any `img` URL for your own product photo file (e.g. `images/tomato.jpg`) if you want fixed images that don't depend on an internet connection.
- Colors and fonts are defined as CSS variables at the top of `styles.css` under `:root`.
