// ---------- PRODUCT DATA ----------
const PRODUCTS = [
  { id: 1, name: "Vine Tomatoes", cat: "produce", price: 34, was: null, unit: "500 g", img: "https://loremflickr.com/400/300/tomato,vegetable" },
  { id: 2, name: "Red Onions", cat: "produce", price: 28, was: 38, unit: "1 kg", img: "https://loremflickr.com/400/300/onion,vegetable" },
  { id: 3, name: "Baby Potatoes", cat: "produce", price: 30, was: null, unit: "1 kg", img: "https://loremflickr.com/400/300/potato,vegetable" },
  { id: 4, name: "Robusta Bananas", cat: "produce", price: 45, was: 55, unit: "dozen", img: "https://loremflickr.com/400/300/banana,fruit" },
  { id: 5, name: "Alphonso Mangoes", cat: "produce", price: 120, was: 150, unit: "1 kg", img: "https://loremflickr.com/400/300/mango,fruit" },
  { id: 6, name: "Baby Spinach", cat: "produce", price: 22, was: null, unit: "250 g", img: "https://loremflickr.com/400/300/spinach,vegetable" },

  { id: 7, name: "Toned Milk", cat: "dairy", price: 32, was: null, unit: "500 ml", img: "https://loremflickr.com/400/300/milk,bottle" },
  { id: 8, name: "Fresh Paneer", cat: "dairy", price: 90, was: 105, unit: "200 g", img: "https://loremflickr.com/400/300/paneer,cheese" },
  { id: 9, name: "Curd Cup", cat: "dairy", price: 25, was: null, unit: "400 g", img: "https://loremflickr.com/400/300/yogurt,curd" },
  { id: 10, name: "Farm Eggs", cat: "dairy", price: 68, was: 78, unit: "tray of 12", img: "https://loremflickr.com/400/300/eggs,carton" },

  { id: 11, name: "Multigrain Bread", cat: "bakery", price: 48, was: null, unit: "400 g", img: "https://loremflickr.com/400/300/bread,loaf" },
  { id: 12, name: "Butter Buns", cat: "bakery", price: 30, was: 36, unit: "pack of 6", img: "https://loremflickr.com/400/300/buns,bakery" },
  { id: 13, name: "Chocolate Cake Slice", cat: "bakery", price: 65, was: null, unit: "150 g", img: "https://loremflickr.com/400/300/chocolatecake,dessert" },
  { id: 14, name: "Butter Cookies", cat: "bakery", price: 55, was: 70, unit: "200 g", img: "https://loremflickr.com/400/300/cookies,biscuit" },

  { id: 15, name: "Fresh Orange Juice", cat: "beverages", price: 85, was: 99, unit: "1 L", img: "https://loremflickr.com/400/300/orangejuice,drink" },
  { id: 16, name: "Cola Bottle", cat: "beverages", price: 40, was: null, unit: "750 ml", img: "https://loremflickr.com/400/300/cola,soda" },
  { id: 17, name: "Filter Coffee Powder", cat: "beverages", price: 145, was: 165, unit: "200 g", img: "https://loremflickr.com/400/300/coffee,powder" },
  { id: 18, name: "Assam Tea Leaves", cat: "beverages", price: 110, was: null, unit: "250 g", img: "https://loremflickr.com/400/300/tea,leaves" },

  { id: 19, name: "Masala Potato Chips", cat: "snacks", price: 20, was: null, unit: "70 g", img: "https://loremflickr.com/400/300/chips,snack" },
  { id: 20, name: "Namkeen Mixture", cat: "snacks", price: 45, was: 55, unit: "200 g", img: "https://loremflickr.com/400/300/namkeen,snack" },
  { id: 21, name: "Cream Biscuits", cat: "snacks", price: 30, was: null, unit: "pack of 4", img: "https://loremflickr.com/400/300/biscuits,snack" },
  { id: 22, name: "Milk Chocolate Bar", cat: "snacks", price: 60, was: 75, unit: "100 g", img: "https://loremflickr.com/400/300/chocolatebar,candy" },

  { id: 23, name: "Laundry Detergent", cat: "household", price: 175, was: 210, unit: "1 kg", img: "https://loremflickr.com/400/300/detergent,laundry" },
  { id: 24, name: "Dish Wash Liquid", cat: "household", price: 95, was: null, unit: "500 ml", img: "https://loremflickr.com/400/300/dishsoap,kitchen" },
  { id: 25, name: "Tissue Roll Pack", cat: "household", price: 60, was: 70, unit: "pack of 4", img: "https://loremflickr.com/400/300/tissue,paper" },
  { id: 26, name: "Handwash Refill", cat: "household", price: 80, was: null, unit: "750 ml", img: "https://loremflickr.com/400/300/handwash,soap" },
];

// ---------- STATE ----------
let state = {
  category: "all",
  search: "",
  sort: "default",
  cart: JSON.parse(localStorage.getItem("mandi_cart") || "{}"),
};

// ---------- ELEMENTS ----------
const grid = document.getElementById("productGrid");
const emptyState = document.getElementById("emptyState");
const resultsCount = document.getElementById("resultsCount");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const categoryBar = document.getElementById("categoryBar");
const cartBtn = document.getElementById("cartBtn");
const cartCount = document.getElementById("cartCount");
const drawer = document.getElementById("cartDrawer");
const drawerOverlay = document.getElementById("drawerOverlay");
const drawerClose = document.getElementById("drawerClose");
const drawerItems = document.getElementById("drawerItems");
const drawerTotal = document.getElementById("drawerTotal");
const drawerSavings = document.getElementById("drawerSavings");
const checkoutBtn = document.getElementById("checkoutBtn");
const toast = document.getElementById("toast");

const money = (n) => "₹" + n.toLocaleString("en-IN");

// ---------- RENDER PRODUCTS ----------
function getFiltered() {
  let list = PRODUCTS.filter(p => {
    const matchesCat = state.category === "all" || p.cat === state.category;
    const matchesSearch = p.name.toLowerCase().includes(state.search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  if (state.sort === "price-asc") list.sort((a, b) => a.price - b.price);
  else if (state.sort === "price-desc") list.sort((a, b) => b.price - a.price);
  else if (state.sort === "discount") {
    list.sort((a, b) => {
      const da = a.was ? (a.was - a.price) / a.was : 0;
      const db = b.was ? (b.was - b.price) / b.was : 0;
      return db - da;
    });
  }
  return list;
}

function renderGrid() {
  const list = getFiltered();
  resultsCount.textContent = list.length;
  grid.innerHTML = "";

  if (list.length === 0) {
    emptyState.hidden = false;
  } else {
    emptyState.hidden = true;
  }

  list.forEach(p => {
    const qty = state.cart[p.id]?.qty || 0;
    const discountPct = p.was ? Math.round(((p.was - p.price) / p.was) * 100) : null;

    const card = document.createElement("article");
    card.className = "card";
    card.innerHTML = `
      <div class="card-photo-wrap">
        ${discountPct ? `<span class="discount-badge">-${discountPct}%</span>` : ""}
        <img src="${p.img}" alt="${p.name}" loading="lazy">
        <span class="unit-badge">${p.unit}</span>
      </div>
      <div class="card-body">
        <p class="card-cat">${labelForCat(p.cat)}</p>
        <h3 class="card-name">${p.name}</h3>
        <div class="price-row">
          <span class="price-now">${money(p.price)}</span>
          ${p.was ? `<span class="price-was">${money(p.was)}</span>` : ""}
        </div>
        <div class="card-footer" data-role="footer"></div>
      </div>
    `;
    const footer = card.querySelector('[data-role="footer"]');
    footer.appendChild(qty > 0 ? buildQtyControl(p, qty) : buildAddButton(p));
    grid.appendChild(card);
  });
}

function labelForCat(cat) {
  return {
    produce: "Fruits & Vegetables",
    dairy: "Dairy & Eggs",
    bakery: "Bakery",
    beverages: "Beverages",
    snacks: "Snacks",
    household: "Household",
  }[cat] || cat;
}

function buildAddButton(p) {
  const btn = document.createElement("button");
  btn.className = "add-btn";
  btn.textContent = "Add to basket";
  btn.addEventListener("click", () => {
    addToCart(p);
  });
  return btn;
}

function buildQtyControl(p, qty) {
  const wrap = document.createElement("div");
  wrap.className = "qty-control";
  wrap.innerHTML = `<button data-action="dec" aria-label="Remove one">−</button><span>${qty}</span><button data-action="inc" aria-label="Add one">+</button>`;
  wrap.querySelector('[data-action="dec"]').addEventListener("click", () => changeQty(p, -1));
  wrap.querySelector('[data-action="inc"]').addEventListener("click", () => changeQty(p, 1));
  return wrap;
}

// ---------- CART LOGIC ----------
function addToCart(p) {
  if (!state.cart[p.id]) state.cart[p.id] = { qty: 0 };
  state.cart[p.id].qty += 1;
  saveCart();
  renderGrid();
  renderDrawer();
  showToast(`${p.name} added to basket`);
}

function changeQty(p, delta) {
  if (!state.cart[p.id]) return;
  state.cart[p.id].qty += delta;
  if (state.cart[p.id].qty <= 0) delete state.cart[p.id];
  saveCart();
  renderGrid();
  renderDrawer();
}

function removeFromCart(id) {
  delete state.cart[id];
  saveCart();
  renderGrid();
  renderDrawer();
}

function saveCart() {
  localStorage.setItem("mandi_cart", JSON.stringify(state.cart));
  const totalQty = Object.values(state.cart).reduce((sum, c) => sum + c.qty, 0);
  cartCount.textContent = totalQty;
}

function renderDrawer() {
  const entries = Object.entries(state.cart);
  drawerItems.innerHTML = "";

  if (entries.length === 0) {
    drawerItems.innerHTML = `<p class="drawer-empty">Your basket is empty. Start adding fresh picks from the market!</p>`;
    drawerTotal.textContent = money(0);
    drawerSavings.textContent = money(0);
    return;
  }

  let total = 0;
  let savings = 0;

  entries.forEach(([id, { qty }]) => {
    const p = PRODUCTS.find(x => x.id == id);
    if (!p) return;
    total += p.price * qty;
    if (p.was) savings += (p.was - p.price) * qty;

    const row = document.createElement("div");
    row.className = "drawer-item";
    row.innerHTML = `
      <img src="${p.img}" alt="${p.name}">
      <div class="drawer-item-info">
        <p class="drawer-item-name">${p.name}</p>
        <p class="drawer-item-price">${money(p.price)} · ${p.unit}</p>
        <button class="drawer-remove" data-id="${p.id}">Remove</button>
      </div>
      <div class="drawer-item-qty">
        <button data-action="dec" data-id="${p.id}">−</button>
        <span>${qty}</span>
        <button data-action="inc" data-id="${p.id}">+</button>
      </div>
    `;
    drawerItems.appendChild(row);
  });

  drawerItems.querySelectorAll('[data-action="dec"]').forEach(b =>
    b.addEventListener("click", () => changeQty({ id: b.dataset.id }, -1)));
  drawerItems.querySelectorAll('[data-action="inc"]').forEach(b =>
    b.addEventListener("click", () => changeQty({ id: b.dataset.id }, 1)));
  drawerItems.querySelectorAll('.drawer-remove').forEach(b =>
    b.addEventListener("click", () => removeFromCart(b.dataset.id)));

  drawerTotal.textContent = money(total);
  drawerSavings.textContent = money(savings);
}

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => toast.classList.remove("show"), 2200);
}

// ---------- EVENTS ----------
searchInput.addEventListener("input", (e) => {
  state.search = e.target.value;
  renderGrid();
});

sortSelect.addEventListener("change", (e) => {
  state.sort = e.target.value;
  renderGrid();
});

categoryBar.addEventListener("click", (e) => {
  const btn = e.target.closest(".cat-pill");
  if (!btn) return;
  categoryBar.querySelectorAll(".cat-pill").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  state.category = btn.dataset.cat;
  renderGrid();
});

cartBtn.addEventListener("click", openDrawer);
drawerClose.addEventListener("click", closeDrawer);
drawerOverlay.addEventListener("click", closeDrawer);

function openDrawer() {
  drawer.classList.add("open");
  drawerOverlay.classList.add("open");
  renderDrawer();
}
function closeDrawer() {
  drawer.classList.remove("open");
  drawerOverlay.classList.remove("open");
}

checkoutBtn.addEventListener("click", () => {
  const entries = Object.entries(state.cart);
  if (entries.length === 0) {
    showToast("Your basket is empty");
    return;
  }
  showToast("This is a demo store — checkout isn't connected to payment.");
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeDrawer();
});

// ---------- INIT ----------
saveCart();
renderGrid();
renderDrawer();
